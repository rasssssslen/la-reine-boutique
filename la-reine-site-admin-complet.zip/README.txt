LA REINE — BOUTIQUE + ADMIN

Pré-requis: Node.js installé sur Windows.

1. Double-cliquez sur start.bat
2. Ouvrez http://localhost:3000
3. Cliquez Admin
4. Identifiants de démonstration:
   utilisateur: admin
   mot de passe: admin123

ADMIN:
- Ajouter des produits
- Choisir une photo depuis le PC
- Modifier / supprimer
- Voir les commandes
- Changer le statut: Nouveau, Confirmé, Expédié, Livré, Annulé

CLIENT:
- Voir les produits
- Rechercher
- La commande démo permet de tester le tableau des commandes.

NOTE: cette version fonctionne sur votre PC. Pour la rendre publique, il faudra un hébergement, une base de données sécurisée, authentification serveur, stockage d'images et paiement/livraison réels.
